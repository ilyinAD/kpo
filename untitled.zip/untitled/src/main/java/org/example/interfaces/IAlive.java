package org.example.interfaces;

public interface IAlive {
    int getFood();
}
