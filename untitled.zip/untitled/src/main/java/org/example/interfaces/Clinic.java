package org.example.interfaces;

import org.example.domain.Animal;

public interface Clinic {
    public boolean checkHealth(Animal animal);
}
