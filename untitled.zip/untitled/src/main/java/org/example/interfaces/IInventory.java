package org.example.interfaces;

public interface IInventory {
    int getNumber();
}
